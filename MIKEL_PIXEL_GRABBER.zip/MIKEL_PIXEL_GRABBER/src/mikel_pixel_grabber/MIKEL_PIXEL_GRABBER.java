/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mikel_pixel_grabber;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import java.io.*;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;

import com.google.gson.Gson;
//import com.google.gson.GsonBuilder;
import java.util.Random;
import java.io.FileWriter;
import java.io.IOException;
import java.util.concurrent.ThreadLocalRandom;

 

/**
 *
 * @author mercolani
 */

public class MIKEL_PIXEL_GRABBER extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        Button btn = new Button();
        btn.setText("Say 'Hello World'");
        btn.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                //System.out.println("Hello World!");
                //DetectPixel();
                String filename = "1080by150.png";
                JavaWalkBufferedImageTest1(filename);
               
                
            }
        });
        
        StackPane root = new StackPane();
        root.getChildren().add(btn);
        
        Scene scene = new Scene(root, 300, 250);
        
        primaryStage.setTitle("Hello World!");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
    public SonarInfo printPixelARGB(int pixel, SonarInfo holder) {
    int alpha = (pixel >> 24) & 0xff;
    int red = (pixel >> 16) & 0xff;
    int green = (pixel >> 8) & 0xff;
    int blue = (pixel) & 0xff;
    
    //int gray = (r + g + b) / 3;

//but if you convert RGB image(24bit) to gray image (8bit) :
   // int gray= img.getRGB(x, y)& 0xFF;/////////will be the gray value

    
    holder.alpha= alpha;
    holder.red = red;
    holder.green = green;
    holder.blue = blue;
    //System.out.println("argb: " + alpha + ", " + red + ", " + green + ", " + blue);
    return holder;
    }
 
  private void marchThroughImage(BufferedImage image, String filename) {
    int w = image.getWidth();
    int h = image.getHeight();
    SonarInfo[] SonarArray = new SonarInfo[w*h];
    System.out.println("width, height: " + w + ", " + h);
    int size = 0;
    for (int i = 0; i < h; i++) {
       if(i%20==0)
       {
       System.out.println("");
       }
        System.out.print("... ");
      for (int j = 0; j < w; j++) {
         
          SonarInfo sI = new SonarInfo();
          
          
        //System.out.println("x,y: " + j + ", " + i);
        
        
        int pixel = image.getRGB(j, i);
        sI = printPixelARGB(pixel,sI);
        sI.x=j;
        sI.y=i;
        sI.pixels=pixel;
        sI.num_pixels_x = w;
        sI.num_pixels_y= h;
        sI.time_increment_type = "M";
        sI.time_increment = 5.0;
        sI.name_of_sonar_screenshot = filename;
        sI.intensity = sI.calculateIntensity(sI.red, sI.blue , sI.green);
        sI.current_deg = ((sI.total_deg/sI.num_pixels_x) * sI.x);
        Double seconds = ((sI.end_time/sI.num_pixels_y) * sI.y);
        
        sI.time_stamp_seconds = seconds*60;
        
        //assign SonarInfo to array for  later
        SonarArray[size]=sI;
        size++;
       // System.out.printI("");
      }
     
    }
   // System.out.println(SonarArray[0].x);
    // System.out.println(h + " * " + w + "= " + size);
    
    //printCopyforValidation(SonarArray, w, h);
   // System.out.println("about to JSON");
    //CreateJsonForValidation(SonarArray);
    CreateCSVfile(SonarArray);
  }
  public void CreateCSVfile(SonarInfo[] SonarArray)
  {
        int w = SonarArray[0].num_pixels_x;
        int h = SonarArray[0].num_pixels_y;
        String filename = SonarArray[0].name_of_sonar_screenshot;
        filename = filename.replaceAll(".png", "");
        String alwaysstartswith = "// DATE 6_SEP_2013\n" +
"// START_TIME 0\n" +
"// CSV_FILE_TYPE SA_DRD\n" +
"// OCEAN_DEPTH 12000\n" +
"// RECORD_LENGTH 180\n" +
"// BAND PBB2\n" +
"// START_FREQ 201\n" +
"// STOP_FREQ 400\n" +
"// UPDATE_RATE 12000\n" +
"// NUM_BEAMS 1080\n" +
"// START_ANGLE 0\n" +
"// BEAM_WIDTH 0.33364\n" +
"// NUM_DE 12\n" +
"// MEASUREMENT_SPACE LINEAR\n" +
"// COLUMN_DEFS D/E TIME(MS) X(YDS) Y(YDS) Z(FT) HDG CSE SPD(KTS) DATA1 DATA2 DATA3 DATA4 DATA5 DATA6 DATA7 DATA8 DATA9 DATA10 DATA11 DATA12 DATA13 DATA14 DATA15 DATA16 DATA17 DATA18 DATA19 DATA20 DATA21 DATA22 DATA23 DATA24 DATA25 DATA26 DATA27 DATA28 DATA29 DATA30 DATA31 DATA32 DATA33 DATA34 DATA35 DATA36 DATA37 DATA38 DATA39 DATA40 DATA41 DATA42 DATA43 DATA44 DATA45 DATA46 DATA47 DATA48 DATA49 DATA50 DATA51 DATA52 DATA53 DATA54 DATA55 DATA56 DATA57 DATA58 DATA59 DATA60 DATA61 DATA62 DATA63 DATA64 DATA65 DATA66 DATA67 DATA68 DATA69 DATA70 DATA71 DATA72 DATA73 DATA74 DATA75 DATA76 DATA77 DATA78 DATA79 DATA80 DATA81 DATA82 DATA83 DATA84 DATA85 DATA86 DATA87 DATA88 DATA89 DATA90 DATA91 DATA92 DATA93 DATA94 DATA95 DATA96 DATA97 DATA98 DATA99 DATA100 DATA101 DATA102 DATA103 DATA104 DATA105 DATA106 DATA107 DATA108 DATA109 DATA110 DATA111 DATA112 DATA113 DATA114 DATA115 DATA116 DATA117 DATA118 DATA119 DATA120 DATA121 DATA122 DATA123 DATA124 DATA125 DATA126 DATA127 DATA128 DATA129 DATA130 DATA131 DATA132 DATA133 DATA134 DATA135 DATA136 DATA137 DATA138 DATA139 DATA140 DATA141 DATA142 DATA143 DATA144 DATA145 DATA146 DATA147 DATA148 DATA149 DATA150 DATA151 DATA152 DATA153 DATA154 DATA155 DATA156 DATA157 DATA158 DATA159 DATA160 DATA161 DATA162 DATA163 DATA164 DATA165 DATA166 DATA167 DATA168 DATA169 DATA170 DATA171 DATA172 DATA173 DATA174 DATA175 DATA176 DATA177 DATA178 DATA179 DATA180 DATA181 DATA182 DATA183 DATA184 DATA185 DATA186 DATA187 DATA188 DATA189 DATA190 DATA191 DATA192 DATA193 DATA194 DATA195 DATA196 DATA197 DATA198 DATA199 DATA200 DATA201 DATA202 DATA203 DATA204 DATA205 DATA206 DATA207 DATA208 DATA209 DATA210 DATA211 DATA212 DATA213 DATA214 DATA215 DATA216 DATA217 DATA218 DATA219 DATA220 DATA221 DATA222 DATA223 DATA224 DATA225 DATA226 DATA227 DATA228 DATA229 DATA230 DATA231 DATA232 DATA233 DATA234 DATA235 DATA236 DATA237 DATA238 DATA239 DATA240 DATA241 DATA242 DATA243 DATA244 DATA245 DATA246 DATA247 DATA248 DATA249 DATA250 DATA251 DATA252 DATA253 DATA254 DATA255 DATA256 DATA257 DATA258 DATA259 DATA260 DATA261 DATA262 DATA263 DATA264 DATA265 DATA266 DATA267 DATA268 DATA269 DATA270 DATA271 DATA272 DATA273 DATA274 DATA275 DATA276 DATA277 DATA278 DATA279 DATA280 DATA281 DATA282 DATA283 DATA284 DATA285 DATA286 DATA287 DATA288 DATA289 DATA290 DATA291 DATA292 DATA293 DATA294 DATA295 DATA296 DATA297 DATA298 DATA299 DATA300 DATA301 DATA302 DATA303 DATA304 DATA305 DATA306 DATA307 DATA308 DATA309 DATA310 DATA311 DATA312 DATA313 DATA314 DATA315 DATA316 DATA317 DATA318 DATA319 DATA320 DATA321 DATA322 DATA323 DATA324 DATA325 DATA326 DATA327 DATA328 DATA329 DATA330 DATA331 DATA332 DATA333 DATA334 DATA335 DATA336 DATA337 DATA338 DATA339 DATA340 DATA341 DATA342 DATA343 DATA344 DATA345 DATA346 DATA347 DATA348 DATA349 DATA350 DATA351 DATA352 DATA353 DATA354 DATA355 DATA356 DATA357 DATA358 DATA359 DATA360 DATA361 DATA362 DATA363 DATA364 DATA365 DATA366 DATA367 DATA368 DATA369 DATA370 DATA371 DATA372 DATA373 DATA374 DATA375 DATA376 DATA377 DATA378 DATA379 DATA380 DATA381 DATA382 DATA383 DATA384 DATA385 DATA386 DATA387 DATA388 DATA389 DATA390 DATA391 DATA392 DATA393 DATA394 DATA395 DATA396 DATA397 DATA398 DATA399 DATA400 DATA401 DATA402 DATA403 DATA404 DATA405 DATA406 DATA407 DATA408 DATA409 DATA410 DATA411 DATA412 DATA413 DATA414 DATA415 DATA416 DATA417 DATA418 DATA419 DATA420 DATA421 DATA422 DATA423 DATA424 DATA425 DATA426 DATA427 DATA428 DATA429 DATA430 DATA431 DATA432 DATA433 DATA434 DATA435 DATA436 DATA437 DATA438 DATA439 DATA440 DATA441 DATA442 DATA443 DATA444 DATA445 DATA446 DATA447 DATA448 DATA449 DATA450 DATA451 DATA452 DATA453 DATA454 DATA455 DATA456 DATA457 DATA458 DATA459 DATA460 DATA461 DATA462 DATA463 DATA464 DATA465 DATA466 DATA467 DATA468 DATA469 DATA470 DATA471 DATA472 DATA473 DATA474 DATA475 DATA476 DATA477 DATA478 DATA479 DATA480 DATA481 DATA482 DATA483 DATA484 DATA485 DATA486 DATA487 DATA488 DATA489 DATA490 DATA491 DATA492 DATA493 DATA494 DATA495 DATA496 DATA497 DATA498 DATA499 DATA500 DATA501 DATA502 DATA503 DATA504 DATA505 DATA506 DATA507 DATA508 DATA509 DATA510 DATA511 DATA512 DATA513 DATA514 DATA515 DATA516 DATA517 DATA518 DATA519 DATA520 DATA521 DATA522 DATA523 DATA524 DATA525 DATA526 DATA527 DATA528 DATA529 DATA530 DATA531 DATA532 DATA533 DATA534 DATA535 DATA536 DATA537 DATA538 DATA539 DATA540 DATA541 DATA542 DATA543 DATA544 DATA545 DATA546 DATA547 DATA548 DATA549 DATA550 DATA551 DATA552 DATA553 DATA554 DATA555 DATA556 DATA557 DATA558 DATA559 DATA560 DATA561 DATA562 DATA563 DATA564 DATA565 DATA566 DATA567 DATA568 DATA569 DATA570 DATA571 DATA572 DATA573 DATA574 DATA575 DATA576 DATA577 DATA578 DATA579 DATA580 DATA581 DATA582 DATA583 DATA584 DATA585 DATA586 DATA587 DATA588 DATA589 DATA590 DATA591 DATA592 DATA593 DATA594 DATA595 DATA596 DATA597 DATA598 DATA599 DATA600 DATA601 DATA602 DATA603 DATA604 DATA605 DATA606 DATA607 DATA608 DATA609 DATA610 DATA611 DATA612 DATA613 DATA614 DATA615 DATA616 DATA617 DATA618 DATA619 DATA620 DATA621 DATA622 DATA623 DATA624 DATA625 DATA626 DATA627 DATA628 DATA629 DATA630 DATA631 DATA632 DATA633 DATA634 DATA635 DATA636 DATA637 DATA638 DATA639 DATA640 DATA641 DATA642 DATA643 DATA644 DATA645 DATA646 DATA647 DATA648 DATA649 DATA650 DATA651 DATA652 DATA653 DATA654 DATA655 DATA656 DATA657 DATA658 DATA659 DATA660 DATA661 DATA662 DATA663 DATA664 DATA665 DATA666 DATA667 DATA668 DATA669 DATA670 DATA671 DATA672 DATA673 DATA674 DATA675 DATA676 DATA677 DATA678 DATA679 DATA680 DATA681 DATA682 DATA683 DATA684 DATA685 DATA686 DATA687 DATA688 DATA689 DATA690 DATA691 DATA692 DATA693 DATA694 DATA695 DATA696 DATA697 DATA698 DATA699 DATA700 DATA701 DATA702 DATA703 DATA704 DATA705 DATA706 DATA707 DATA708 DATA709 DATA710 DATA711 DATA712 DATA713 DATA714 DATA715 DATA716 DATA717 DATA718 DATA719 DATA720 DATA721 DATA722 DATA723 DATA724 DATA725 DATA726 DATA727 DATA728 DATA729 DATA730 DATA731 DATA732 DATA733 DATA734 DATA735 DATA736 DATA737 DATA738 DATA739 DATA740 DATA741 DATA742 DATA743 DATA744 DATA745 DATA746 DATA747 DATA748 DATA749 DATA750 DATA751 DATA752 DATA753 DATA754 DATA755 DATA756 DATA757 DATA758 DATA759 DATA760 DATA761 DATA762 DATA763 DATA764 DATA765 DATA766 DATA767 DATA768 DATA769 DATA770 DATA771 DATA772 DATA773 DATA774 DATA775 DATA776 DATA777 DATA778 DATA779 DATA780 DATA781 DATA782 DATA783 DATA784 DATA785 DATA786 DATA787 DATA788 DATA789 DATA790 DATA791 DATA792 DATA793 DATA794 DATA795 DATA796 DATA797 DATA798 DATA799 DATA800 DATA801 DATA802 DATA803 DATA804 DATA805 DATA806 DATA807 DATA808 DATA809 DATA810 DATA811 DATA812 DATA813 DATA814 DATA815 DATA816 DATA817 DATA818 DATA819 DATA820 DATA821 DATA822 DATA823 DATA824 DATA825 DATA826 DATA827 DATA828 DATA829 DATA830 DATA831 DATA832 DATA833 DATA834 DATA835 DATA836 DATA837 DATA838 DATA839 DATA840 DATA841 DATA842 DATA843 DATA844 DATA845 DATA846 DATA847 DATA848 DATA849 DATA850 DATA851 DATA852 DATA853 DATA854 DATA855 DATA856 DATA857 DATA858 DATA859 DATA860 DATA861 DATA862 DATA863 DATA864 DATA865 DATA866 DATA867 DATA868 DATA869 DATA870 DATA871 DATA872 DATA873 DATA874 DATA875 DATA876 DATA877 DATA878 DATA879 DATA880 DATA881 DATA882 DATA883 DATA884 DATA885 DATA886 DATA887 DATA888 DATA889 DATA890 DATA891 DATA892 DATA893 DATA894 DATA895 DATA896 DATA897 DATA898 DATA899 DATA900 DATA901 DATA902 DATA903 DATA904 DATA905 DATA906 DATA907 DATA908 DATA909 DATA910 DATA911 DATA912 DATA913 DATA914 DATA915 DATA916 DATA917 DATA918 DATA919 DATA920 DATA921 DATA922 DATA923 DATA924 DATA925 DATA926 DATA927 DATA928 DATA929 DATA930 DATA931 DATA932 DATA933 DATA934 DATA935 DATA936 DATA937 DATA938 DATA939 DATA940 DATA941 DATA942 DATA943 DATA944 DATA945 DATA946 DATA947 DATA948 DATA949 DATA950 DATA951 DATA952 DATA953 DATA954 DATA955 DATA956 DATA957 DATA958 DATA959 DATA960 DATA961 DATA962 DATA963 DATA964 DATA965 DATA966 DATA967 DATA968 DATA969 DATA970 DATA971 DATA972 DATA973 DATA974 DATA975 DATA976 DATA977 DATA978 DATA979 DATA980 DATA981 DATA982 DATA983 DATA984 DATA985 DATA986 DATA987 DATA988 DATA989 DATA990 DATA991 DATA992 DATA993 DATA994 DATA995 DATA996 DATA997 DATA998 DATA999 DATA1000 DATA1001 DATA1002 DATA1003 DATA1004 DATA1005 DATA1006 DATA1007 DATA1008 DATA1009 DATA1010 DATA1011 DATA1012 DATA1013 DATA1014 DATA1015 DATA1016 DATA1017 DATA1018 DATA1019 DATA1020 DATA1021 DATA1022 DATA1023 DATA1024 DATA1025 DATA1026 DATA1027 DATA1028 DATA1029 DATA1030 DATA1031 DATA1032 DATA1033 DATA1034 DATA1035 DATA1036 DATA1037 DATA1038 DATA1039 DATA1040 DATA1041 DATA1042 DATA1043 DATA1044 DATA1045 DATA1046 DATA1047 DATA1048 DATA1049 DATA1050 DATA1051 DATA1052 DATA1053 DATA1054 DATA1055 DATA1056 DATA1057 DATA1058 DATA1059 DATA1060 DATA1061 DATA1062 DATA1063 DATA1064 DATA1065 DATA1066 DATA1067 DATA1068 DATA1069 DATA1070 DATA1071 DATA1072 DATA1073 DATA1074 DATA1075 DATA1076 DATA1077 DATA1078 DATA1079 DATA1080 \n";
        
        String createSonar ="";
       
       // String buildrow ="1,0,0,0,0,0,0,0,0,";
        String[] rows = new String[SonarArray[0].num_pixels_y];
        String[] timestamp = new String[SonarArray[0].num_pixels_y];
        
        for(int i=0;i<SonarArray[0].num_pixels_y;i++)
        {
        rows[i]="";
        timestamp[i]="";
        }
       
        for(SonarInfo s : SonarArray)
    {
       
        String val = Integer.toString(s.intensity)+ ",";
        int y = s.y;
        rows[y] = rows[y].concat(val);
        //buildrow = buildrow.concat(val);
        
        String time = Double.toString(s.time_stamp_seconds)+ ",";
        timestamp[y] = time;
      
     
    }
        for(int i=0;i<SonarArray[0].num_pixels_y;i++)
        {
            for(int y=1;y<13;y++)
            {
                if(y==1)
                {
                    rows[i]=  Integer.toString(y)+","+timestamp[i]+"0,0,0,0,0,0," + rows[i];
                }
                
                else
                {
                   
                    rows[i]=  rows[i].substring(1);
                    if(y==11|y==12)
                    {
                    rows[i]=  rows[i].substring(1);
                    }
               /*   else
                    {
                   rows[i]=  rows[i].substring(2);
                   }
                   
                        */
                    rows[i]= Integer.toString(y).concat(rows[i]);
              //  rows[i]=rows[i].replace(",no1,no2,no3,no4,no5,no6,", "");
              //  rows[i] = rows[i].substring(1);
            //    rows[i]=  Integer.toString(y)+","+timestamp[i]+",no1,no2,no3,no4,no5,no6," + rows[i];
                }
                /*else
                {
                    if(y==11 | y==12)
                    {
                    rows[i] = rows[i].substring(17);
                    }
                    else
                    {
                rows[i] = rows[i].substring(16);
                    }
                    
                }*/
                if(y==1)
                {
                int lastcomma = rows[i].lastIndexOf(",");
               int length = rows[i].length();
                rows[i] = rows[i].substring(0,length-1);
                lastcomma = rows[i].lastIndexOf(",");
                length = rows[i].length();
                int removeat = length - lastcomma;
                rows[i] = rows[i].substring(0,length-removeat)+",";
                }
               // rows[i] = rows[i].concat(",");
             createSonar = createSonar.concat(rows[i]+"\n");
            }
      
        }
        //createSonar = createSonar.concat("removeme");
        //createSonar = createSonar.replace(",removeme","");
        alwaysstartswith = alwaysstartswith.concat(createSonar);
        
      try (FileWriter writer = new FileWriter(filename+".csv")) {
System.out.println("writing file");
            
            try (BufferedWriter bw = new BufferedWriter(writer)) {
                bw.write(alwaysstartswith);
            }

			System.out.println("Done");

        } catch (IOException e) {
        }
  }
  
  public void CreateJsonForValidation(SonarInfo[] SonarArray)
  {
 // Staff staff = createDummyObject();

        //1. Convert object to JSON string
        Gson gson = new Gson();
        String json = "";
        String jsonline;
        String filename = SonarArray[0].name_of_sonar_screenshot;
        filename = filename.replaceAll(".png", "");
        int i=0;
        
        for(SonarInfo s : SonarArray)
    {
        
     jsonline = gson.toJson(s);
     json = json.concat(jsonline);
     if(i%500==0)
       {
       System.out.println("still running json");
       i=0;
       }
     i++;
     if(i%50==0)
     {
         if(i<=50)
         {
             Random rand;

    // nextInt is normally exclusive of the top value,
    // so add 1 to make it inclusive
    int randomNum = ThreadLocalRandom.current().nextInt(0, 8 + 0);
             for(int y=randomNum;y>0;y--)
             {
        System.out.print(".");
             }
             System.out.print(" ");
         }
     }
   
    }
       
      
        try (FileWriter writer = new FileWriter(filename+".json")) {
System.out.println("writing file");
            
			BufferedWriter bw = new BufferedWriter(writer);
			bw.write(json);
			bw.close();

			System.out.println("Done");

        } catch (IOException e) {
            e.printStackTrace();
        }
       

  }
  
  public void printCopyforValidation(SonarInfo[] SonarArray, int w, int h)
  {
  
  BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);

    for(SonarInfo s : SonarArray)
    {
    img.setRGB(s.x, s.y, s.pixels);
    }
   // BufferedImage buffImg = toBufferedImage(img);
    File outputfile = new File("image2.png");
   
    try
    {
    ImageIO.write(img, "png", outputfile);
    }
    catch(IOException ex)
    {
    System.out.println("Error: " + ex.getMessage());
    }
    System.out.println("done creating copy of image");
  }
 
 
  public void JavaWalkBufferedImageTest1(String filename) {
    try {
      // get the BufferedImage, using the ImageIO class
       String path = System.getProperty("user.dir");
          File file= new File(path + "\\"+filename);
  BufferedImage image = ImageIO.read(file);
      marchThroughImage(image, filename);
    } catch (IOException e) {
      System.err.println(e.getMessage());
    }
  }

    
    
    
    
}
