/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mikel_pixel_grabber;

/**
 *
 * @author mercolani
 */
public class SonarInfo {
    int alpha;
    int red;
    int blue;
    int green;
    int intensity;
    int x;
    int y;
    int pixels;
    
    Double start_time = 0.0;
    Double end_time = 35.0;
    Double time_increment = 5.0;//asssumed to be in minutes
    String time_increment_type = "M";//seconds, minutes, hours
    String time_stamp_display;// end_time/num_pixels_y * y
    //HH:MM
    Double time_stamp_seconds;
    float start_deg= 0;
    float stop_deg= 255;
    float total_deg = 255;
    int num_pixels_x;
    int num_pixels_y;
    String name_of_sonar_screenshot;
    
    float current_deg;
    // 360 / num_pixels_x * y
    
    public Double checkRGB(int color)
    {
        Double newcolorval;
    if(color <= 0.03928)
        {
        newcolorval = color/12.92;
        }
        else
        {
        newcolorval=  Math.pow(((color+.055)/1.055), 2.4) ;
        }
    return newcolorval;
    }
    
    public int calculateIntensity(int r, int g, int b)
    {
        double R;
        double G;
        double B;
        
        double L=0;
    /*
        For the sRGB colorspace, the relative luminance of a color is defined as 
        L = 0.2126 * R + 0.7152 * G + 0.0722 * B where R, G and B are defined as:
if RsRGB <= 0.03928 then R = RsRGB/12.92 else R = ((RsRGB+0.055)/1.055) ^ 2.4
if GsRGB <= 0.03928 then G = GsRGB/12.92 else G = ((GsRGB+0.055)/1.055) ^ 2.4
if BsRGB <= 0.03928 then B = BsRGB/12.92 else B = ((BsRGB+0.055)/1.055) ^ 2.4

        
        luminosity is 0.21 R + 0.72 G + 0.07 B
*/
        /*
        R = checkRGB(r);
        G = checkRGB(g);
        B = checkRGB(b);
       */
        R = r;
        G = g;
        B = b;
               
        L = ((0.2126 * R) + (0.7152 * G) + (0.0722 * B))/3;
        
        int grayscale = (int) L;
        
        return grayscale;
    }
}
